<?php

    // Configuração do Banco de Dados
    define('HOST', 'localhost');  
    define('DBNAME', 'aula');    
    define('USER', 'root');  
    define('PASSWORD', '');
    define('DRIVER', 'mysql'); 
    define('CHARSET', 'utf8');

    // Configuração da Aplicação (dev ou prod)
    // dev mostra os erros e prod não mostra os erros
    define('PERFIL', 'dev');
    
?>
