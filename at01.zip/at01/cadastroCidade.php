<?php 
    include 'acaoCidade.php';

    $acao = isset($_GET['acao']) ? $_GET['acao'] : '';
    $dados = array();
    if ($acao == 'editar'){
        $id = isset($_GET['id']) ? $_GET['id'] : '';
        $dados = findById($id);
        //var_dump($dados);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Cidade</title>
    <link rel="stylesheet" href="estilo.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Abel&family=Red+Hat+Display:wght@300&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<a href="index.html"><button class="btn btn-primary">Voltar</button></a>
<body>
    <h1>Cadastro de Cidade:</h1>
    <div class='row'>
        <div class='col-12'>
            <form action="acaoCidade.php" method="post">
                <div class='row'>
                    <div class='col-2'>
                        <label for="id">ID:</label>
                    </div>
                    <div class='col-10'>
                        <input type="text" id='id' name='id' readonly value="<?php if ($acao == 'editar') echo $dados['id']; else echo "0"; ?>">
                    </div>
                </div>
                <div class='row'>
                    <div class='col-2'>
                        <label for="nome">Nome:</label>
                    </div>
                    <div class='col-10'>
                        <input type="text" id='nome' name='nome' value="<?php if ($acao == 'editar') echo $dados['nome'];?>">
                    </div>
                </div>       
                <div class='row'>
                    <div class='col-2'>
                        <label for="estado">Estado:</label>
                    </div>
                    <div class='col-10'>
                        <input type="text" estado='estado' name='estado' value="<?php if ($acao == 'editar') echo $dados['estado'];?>">
                    </div>
                </div>  
                <div class='row'>
                    <div class='col-12'>
                        <button type='submit' name='acao' id='acao' value='salvar' class="btn btn-success">Salvar</button><br><br>
                    </div>
                </div>       
            </form>
        </div>
    </div>    
</body>
</html>