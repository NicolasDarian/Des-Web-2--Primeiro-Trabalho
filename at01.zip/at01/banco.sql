create schema aula;

CREATE TABLE cidade (
  id int(11) NOT NULL AUTO_INCREMENT,
  nome varchar(45) DEFAULT NULL,
  estado varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
  );

  CREATE TABLE contatos (
  id int(11) NOT NULL AUTO_INCREMENT,
  nome varchar(45) DEFAULT NULL,
  sobrenome varchar(45) DEFAULT NULL,
  email varchar(45) DEFAULT NULL,
  dtnasci date DEFAULT NULL,
  telefone varchar(45) DEFAULT NULL,
  cidade varchar(45) DEFAULT NULL,
  obs varchar(100) DEFAULT NULL,
  vivo int DEFAULT NULL,
  PRIMARY KEY (`id`)
  );

create table hobbies(
id int(11) NOT NULL AUTO_INCREMENT,
nome varchar(45) DEFAULT NULL,
descricao varchar(300) DEFAULT NULL,
PRIMARY KEY (`id`)
);

create table contato_hobbie(
idContato int not null,
idHobbie int not null,
PRIMARY KEY(idContato,idHobbie),
INDEX(idContato), CONSTRAINT contatos_id_fk FOREIGN KEY (idContato) REFERENCES contato(id),
INDEX(idHobbie), CONSTRAINT hobbies_id_fk FOREIGN KEY (idHobbie) REFERENCES hobbies(id)
);

create table contato_hobbie(
idContato int not null,
idHobbie int not null,
PRIMARY KEY(idContato,idHobbie),
CONSTRAINT contatos_id_fk FOREIGN KEY (idContato) REFERENCES contatos(id),
CONSTRAINT hobbies_id_fk FOREIGN KEY (idHobbie) REFERENCES hobbies(id)
);