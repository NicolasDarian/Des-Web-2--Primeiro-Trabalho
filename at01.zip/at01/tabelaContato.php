<?php 
    require_once "conf/Conexao.php";
?>
      <title>Contatos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <div class="container-fluid">
    <br>
    <br>
    <a href="index.html"><button class="btn btn-primary">Voltar</button></a><br>
    <form action="" method="get">
        <fieldset>
        <legend><h2>Contato:</h2></legend>

        <div class="row align-items-end">
            <div class="col-3">
                
                <input class="form-control" type="text" name="filtro" id="filtro">
            </div>
            <div class="col-2">
            <button type="submit" class="btn btn-primary">Consultar</button><br>
            </div>
            <div class="col-1">
            <a class='btn btn-primary' href="cadastroContatos.php">Cadastrar</a>
            </div>
        </div>
        </fieldset>
    </form>

    <br>
    <table class="table table-striped">
    <thead>
        <tr class='table-titulo'>
            <th>Id</th>
            <th>Nome</th>
            <th>Sobrenome</th>  
            <th>E-mail</th>
            <th>Data de Nascimento</th>
            <th>Telefone</th>
            <th>Cidade</th>
            <th>Observações</th>
            <th>Vivo</th>
            <th>Detalhes</th>
            <th>Editar</th>
            <th>Excluir</th>
        </tr>
    </thead>
    <tbody>
<?php
    $conexao = Conexao::getInstance();

    $filtro = isset($_GET['filtro']) ? $_GET['filtro']: "";
    $consulta=$conexao->query("SELECT contatos.id, cidade.nome as NomeCidade,sobrenome, cidade.id as idCidade, contatos.nome as NomeContato,email,dtnasci,telefone,cidade,obs,vivo FROM contatos LEFT JOIN cidade ON contatos.cidade = cidade.id where contatos.nome like '$filtro%';");
    
    while($linha=$consulta->fetch(PDO::FETCH_ASSOC)){
            echo "<tr>
                    <td>{$linha['id']}</td>
                    <td>{$linha['NomeContato']}</td>
                    <td>{$linha['sobrenome']}</td>
                    <td>{$linha['email']}</td>
                    <td>{$linha['dtnasci']}</td>
                    <td>{$linha['telefone']}</td>
                    <td>{$linha['NomeCidade']}({$linha['idCidade']})</td>
                    <td>{$linha['obs']}</td>
                    <td>{$linha['vivo']}</td>
                    <td><a href='showContato.php?id={$linha['id']}' class='btn btn-success'>Detalhes</a></td>
                    <td><a href='cadastroContatos.php?acao=editar&id={$linha['id']}' class='btn btn-warning'>Editar</a></td>
                    <td><a onClick = 'return excluir();' href='acao.php?acao=excluir&id={$linha['id']}'. class='btn btn-danger'>Excluir</a></td>
                  </tr>\n";
        }
?>
</tbody>
</table>
</div>