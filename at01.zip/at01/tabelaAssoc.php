<?php
    require_once "conf/Conexao.php";

    include 'acaoAssoc.php';

    $acao = isset($_GET['acao']) ? $_GET['acao'] : '';
    $dados = array();
    if ($acao == 'editar'){
        $idContato = isset($_GET['idContato']) ? $_GET['idContato'] : 0;
        $idHobbie = isset($_GET['idHobbie']) ? $_GET['idHobbie'] : 0;
        $dados = findById($idContato,$idHobbie);
        //var_dump($dados);
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cadastro de Hobbies</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    </head>
    <body>
        <a href="cadastroContatos.php" class="btn btn-primary">Voltar</a>
        <b><h2>Cadastro para hobbies e contatos:</h2></b>
        
        <div class='row teste'>
            <div class='col-6 '>
                <form action="acaoAssoc.php" method="post">
                    <input type="hidden" name="id" value="<?php if ($acao == 'editar') echo""; else echo 0; ?>">

                    <input type="hidden" name="idContato_codigo" value="<?php if ($acao == 'editar') echo $dados['idContato']; else echo 0; ?>">

                    <input type="hidden" name="idHobbie_codigo" value="<?php if ($acao == 'editar') echo $dados['idHobbie']; else echo 0; ?>">
                    <div class='row'>
                        <div class='col-6'>
                            <label for="contato">Contato:</label>
                            <select name="idContato" id="idContato">
                                    <?php
                                        $conexao = Conexao::getInstance();

                                        $consulta=$conexao->query("SELECT*FROM contatos;");

                                        while($linha=$consulta->fetch(PDO::FETCH_ASSOC)){
                                            if ($linha['id'] == $dados['idContato']) {
                                                echo "<option value='".$linha['id']."' selected>".$linha['nome']."</option>";
                                            }else{
                                                echo "<option value='".$linha['id']."'>".$linha['nome']."</option>";
                                            }
                                        }
                                    ?>
                            </select>
                        </div>
                    

                        <div class='col-6'>
                            <label for="descricao">Hobbie:</label>
        
                            <select name="idHobbie" id="idHobbie">
                                <?php
                                    $conexao = Conexao::getInstance();

                                    $consulta=$conexao->query("SELECT*FROM hobbies;");

                                    while($linha=$consulta->fetch(PDO::FETCH_ASSOC)){

                                        if ($linha['id'] == $dados['idHobbie']) {
                                            echo "<option value='".$linha['id']."' selected>".$linha['nome']."</option>";
                                        }else{
                                            echo "<option value='".$linha['id']."'>".$linha['nome']."</option>";
                                        }
                                    }

                                ?>
                            </select>
                        </div>
                    </div>  

                        <br>
                    <div class='row'>
                        <div class='col-12'>
                            <button type='submit' name='acao' class="btn btn-success" id='acao' value='salvar'>Salvar</button>
                        </div>
                    </div>       
                </form>
            </div>
        </div> 
        <div class='row'>
            <?php

            ?>
            <div>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Contato</th>
                            <th>Hobbie</th>
                            <th>Editar</th>
                            <th>Excluir</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        <?php
                                $conexao = Conexao::getInstance();
                                $consulta=$conexao->query("SELECT *FROM contato_hobbie;");
                                while($linha=$consulta->fetch(PDO::FETCH_ASSOC)){
                                    echo "
                                        <td>{$linha['idContato']}</td>
                                        <td>{$linha['idHobbie']}</td>
                                        <td><a class='btn btn-warning' href='tabelaAssoc.php?acao=editar&idContato={$linha['idContato']}&idHobbie={$linha['idHobbie']}'>Editar</a></td>
                                        <td><a class='btn btn-danger' onClick = 'return excluir();' href='acaoAssoc.php?acao=excluir&idContato={$linha['idContato']}&idHobbie={$linha['idHobbie']}'>Excluir</a></td>
                                        </tr>\n
                                    ";
                                
                                }
                            ?>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>