<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
</html>
<?php

require_once "conf/Conexao.php";

$acao = "";
switch($_SERVER['REQUEST_METHOD']) {
    case 'GET':  $acao = isset($_GET['acao']) ? $_GET['acao'] : ""; break;
    case 'POST': $acao = isset($_POST['acao']) ? $_POST['acao'] : ""; break;
}

switch($acao){
    case 'excluir': excluir(); break;
    case 'salvar': {
        $id = isset($_POST['id']) ? $_POST['id'] : 0;
        if ($id == 0)
            salvar(); 
        else
            editar();
        break;
    }
}

function excluir(){    
    $id = isset($_GET['id']) ? $_GET['id']:0;
    $conexao = Conexao::getInstance();
    $stmt = $conexao->prepare("DELETE FROM hobbies WHERE id = :id");
    $stmt->bindParam('id', $id, PDO::PARAM_INT);  
    $stmt->execute();
    header("location:tabelaHobbie.php");
}

function editar(){
    $dados = formToArray();
    
    $conexao = Conexao::getInstance();
    $sql = "UPDATE hobbies SET nome = '".$dados['nome']."',
                            descricao = '".$dados['descricao']."' WHERE id = ".$dados['id'].";";
    $conexao = $conexao->query($sql);
    header("location:tabelaHobbie.php");
}

function salvar(){
 $dados = formToArray();    

    $conexao = Conexao::getInstance();
    $sql = "INSERT INTO hobbies (nome, descricao) VALUES ('".$dados['nome']."','".$dados['descricao']."');";
    $conexao = $conexao->query($sql);
    header("location:tabelaHobbie.php");
}

function formToArray(){
    $id = isset($_POST['id']) ? $_POST['id']: 0;
    $nome = isset($_POST['nome']) ? $_POST['nome']: 0;
    $descricao = isset($_POST['descricao']) ? $_POST['descricao']: 0;

    $dados = array(
        'id' => $id,
        'nome' => $nome,
        'descricao' => $descricao,
    );

    return $dados;
}

function findById($id){
    $conexao = Conexao::getInstance();
    $conexao = $conexao->query("SELECT * FROM hobbie WHERE id = $id;");
    $result = $conexao->fetch(PDO::FETCH_ASSOC);
    return $result; 
}