<?php
define ('MYSQL_HOST','localhost');
define ('MYSQL_USUARIO','root');
define ('MYSQL_SENHA','');
define ('MYSQL_DB','aula');
define ('MYSQL_PORT','3306');

define ('MYSQL_DSN',"mysql:host=".MYSQL_HOST.";port=".MYSQL_PORT.";dbname=".MYSQL_DB.";charset=UTF8");

?>