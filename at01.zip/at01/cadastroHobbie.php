<?php 
    include 'acaoHobbie.php';

    $acao = isset($_GET['acao']) ? $_GET['acao'] : '';
    $dados = array();
    if ($acao == 'editar'){
        $id = isset($_GET['id']) ? $_GET['id'] : '';
        $dados = findById($id);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Contatos</title>
    <link rel="stylesheet" href="estilo.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Abel&family=Red+Hat+Display:wght@300&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
   <script src="scriptcontatos.js"></script>
</head>
<a href="index.html"><button class="btn btn-primary">Voltar</button></a>
<body>
    <h1>Cadastro de Hobbies</h1>
    <div class='row'>
        <div class='col-12'>
            <form action="acaoHobbie.php" method='post'>
                <div class="row">
                    <div class='col-2'>
                        <label for="nome">id:</label>
                    </div>
                    <div class='col-4'>
                        <input type="text" name='id' id='id' value="<?php if ($acao == 'editar') echo $dados['id']; else echo 0; ?>">
                    </div>
                </div>
                    
                <div class='row'>
                    <div class='col-2'>
                        <label for="nome">Nome:</label>
                    </div>
                    <div class='col-4'>
                        <input type="text" name='nome' id='nome' value="<?php if ($acao == 'editar') echo $dados['nome']; else echo ""; ?>">
                    </div>
                <div class='row'>
                    <div class='col-2'>
                        <label for="descricao">
                            Descrição:
                        </label>
                    </div>
                    <div class='col-10'>
                        <textarea name="descricao" id="descricao" cols="30" rows="10"><?php if ($acao == 'editar') echo $dados['descricao']; else echo ""; ?></textarea>
                    </div>
                </div>
                <div class='row'>
                    <div class='col-12'> 
                        <button name='acao' id='acao' value='salvar' type='submit' class='btn btn-success'>Salvar</button><br><br>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>